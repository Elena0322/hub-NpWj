import torch
import torch.nn as nn
import torch.optim as optim

#torch:张量、随机数
#nn:神经网络、损失函数
#optim：优化器（用来更新模型）

print("=========1、造数据=========")

dim = 3   #每个输入向量长度=3,相当于3维向量

sample_num = 100   #造100个训练样本

x = torch.randn(sample_num,dim)   #造100个样本，每个样本3个随机小数

y = torch.argmax(x,dim=1)     #自动生成标签：哪个数最大，标签就是几

class SimpleNet(nn.Module):       #这里相当于我定义一个函数叫SimpleNet,继承nn.Module里面的
    def __init__(self):           #这个相当于固定的初始化函数，写死的不用改
        super().__init__()        #这里是激活我继承的大佬nn.Module

        self.linear = nn.Linear(in_features = 3,out_features = 3) #上面相当于我把框架搭好了，in_features &out_features这两个也是写死的，自己写的名字不行
        #这里是我还需要往里面添置或是搬出去东西，做一个限制，所以要给个条件，输出是多少，输入是多少

    def forward(self,x): #这里的forward是每次我写神经网络的时候必须要写的东西，x是我上面生成的随机数据
                           #self相当于我上面定义的SimpleNet,他继承了nn.Module，
                           # 可以帮我加工我的x里面的数据，再打印出来。
        out = self.linear(x)  #这里就相当于我上面定义的self.linear，他输出必须是我上面定义的三个数
        return out

 #初始化模型   
model = SimpleNet()

#多分类专用损失
loss_fn = nn.CrossEntropyLoss()  #这里nn.CrossEntropyLoss()的作用是模型猜的和真实的对比，写死的

#优化器，用来训练更新参数，下面的SGD是其中一种，还可以改成其他的，除了这个地方我还可以改lr后面的值，看需要来改
optimizer = optim.SGD(model.parameters(),lr=0.01)   #model.parameters在这里的作用是挑出必须要修改的东西给到SGD去训练，lr=0.01相当于每次只改0.01倍

for epoch in range(500):   #这里相当于我定义训练500轮
    #1、模型训练
    pred = model(x)        #这里的pred=model(x)会调用我上面写的SimpleNet，model（x）里面的x就相当于我上面先造的数据随机生
                           #成的一个三维向量，作为输入带入SimpleNet里面去计算结果，然后再return out出来
    #2、计算损失,看算得准不准
    loss = loss_fn(pred,y)
    #3、清空梯度，反向传播，更新模型
    optimizer.zero_grad()     #这里是写死的，会自己把上面跑过的旧的记录自己删掉，跑一轮删掉一轮，只要训练大模型都需要用到。
    loss.backward()           #这里也是写死的，单独检查当前这轮哪错了，哪里需要修改的，然后给到loss.backward()，只要用pytorch训练大模型也都需要
    optimizer.step()          #这里也是写死的，拿到backward给的修改清单需要根据要修改的地方去修改，只要用pytorch训练大模型也都需要

    #每50轮打印一次损失
    if epoch % 10 == 0:
        print("轮数:",epoch,"损失:",loss.item())

    # 自己写一个测试向量
test_x = torch.tensor([[0.3, 2.1, 0.3]])

# 模型预测
test_pred = model(test_x)
# 选出最大值下标 = 预测类别
result = torch.argmax(test_pred, dim=1)

print("预测类别：", result.item())