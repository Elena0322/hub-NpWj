import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset,DataLoader  #torch.utils.data是pytorch专门哟哦你过来装数据集，家在数据的工具包
import random     #Dataset,DataLoader是从里面拿出来的两个工具类；Dateset自己定义数据长什么样子，DataLoader自动帮你分批打乱顺序 

"""
设计一个以文本为输入的多分类任务，实验一下用RNN，LSTM等模型的跑通训练。如果不知道怎么设计，
可以选择如下任务:对一个任意包含“你”字的五个字的文本，“你”在第几位，就属于第几类。
"""


# ===================== 1. 构造数据集 =====================
# 通用汉字库，用来随机生成5个字，保证只有一个「你」
chars = "一二三四五六七八九十山水风花雪月春秋夏秋冬云雨雪晨星"
num_samples = 2000  # 总样本数
data = []    #先建一个空列表 ，等会算好了后再放进来。
label_map = {0:0, 1:1, 2:2, 3:3, 4:4}

for label in range(5):
    for _ in range(num_samples // 5):
        # 生成5个字
        text_list = random.sample(chars, 5)  #从chars里面随机抽出5个字
        # 把第label位置替换成「你」
        text_list[label] = "你"  #比如lable是0，就把第一个字替换成”你“，同理lable是几，就是同一句话的第几个字替换
        text = "".join(text_list)  #这里是把text_list随机生成的5个字合成一句话
        data.append((text, label))  #这里的data跑完之后会把所有的数据放到data=[]里面。

# 划分训练集、测试集
random.shuffle(data) #随机把data里面的数据打乱，相当于洗牌，打乱先后顺序，只是没打乱之前前400条全是lable=0以此类推，打乱了后就乱七八糟混在一起
train_data = data[:1600] #train_data训练前1600条，相当于取到1599条
test_data = data[1600:]  #test_data训练后1600到2000，相当于1600-1999条做测试

# ===================== 2. 文本字典与编码 =====================
# 建立字符词典
all_chars = list(set([c for text, _ in data for c in text]))  #先用c遍历一下data里面的每一个字，然后再用set把里面重复的去掉，然后再把他们转化为list，相当于在这里给他们一个独一无二的标签，确保找的时候不会遇到一样的字
char2idx = {c:i+1 for i, c in enumerate(all_chars)}  # 0留作padding；enumerate是把all_chars里面的字都遍历一遍每个字给个号，c吐出的是字，i是标记，默认从1开始，前面要留给padding
vocab_size = len(char2idx) + 1   #len是计算长度，➕1是把padding 0算进来。主要是为了给神经网络设置范围。

def text2vec(text):
    """5字文本转数字向量"""
    return [char2idx[c] for c in text]   #这里的text如果我给他定义叫：你要吃个屁，如果去char2idx里面找，找到了会返回下标，找不到则会报错

# ===================== 3. 自定义数据集 =====================
class TextDataset(Dataset):
    def __init__(self, dataset):
        self.dataset = dataset     #外部接收数据存到self.dataset里面，这是固定写法
    
    def __len__(self):    #告诉dataset我总共有多少条数据，不写len直接报错，也是固定写法
        return len(self.dataset)
    
    def __getitem__(self, idx):   #getitem的作用让我的类可以支持dataset[index]
        text, label = self.dataset[idx]  #这里的idx从0开始取，依次从0开始取出来，text和label，直至把所有的数据都取完。
        vec = text2vec(text)   #这里的text2vec能把我的text文本转化成向量；text2vec是转向量的函数。有一个embedding表，相当于词典，把对应的字找出来，转化成向量。
        return torch.tensor(vec), torch.tensor(label, dtype=torch.long)  #这里是把vec转成pytorch张量，把label转成一个整数张量

train_dataset = TextDataset(train_data)  #TextDataset是把格式转化成pytorch能识别的格式
test_dataset = TextDataset(test_data)
train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True) #shuffle=True把原始的train_dataset打乱顺序，每32条分成一包等着模型来拿。
test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False) #shuffle=False不打乱顺序，只分批，不乱序。

# ===================== 4. 搭建 RNN / LSTM 模型 =====================
# 超参数
embed_dim = 16  #每个字用16个数字来表示，也可以用其他的
hidden_dim = 32  #这个模型的大脑有32个脑细胞来思考，太多了太聪明了容易想歪，太少了太笨了
num_class = 5    #这个是最后想要把数据用几类来表示。

# 1. 基础RNN模型
class RNNClassifier(nn.Module):  #rnn会一直在一张纸上写，纸就这么大，后面内容多了，前面的直接被覆盖
    def __init__(self, vocab_size, embed_dim, hidden_dim, num_class):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim)   #vocab_size=字典多大，多少个字；embed_dim=每个汉字转成16个数字组成的向量，前面定义的，nn.Embedding是固定的相当于给这个函数装了个功能
        self.rnn = nn.RNN(embed_dim, hidden_dim, batch_first=True) #batch_first=True强制让batch放在第一维度，batch_first=False默认让batch放在第二维度，相当于告诉rnn我给你的数据格式是多少句话你按照这个读
              #RNN = 按顺序读取文字，记住上下文、记住字的位置，专门处理序列（句子）的神经网络
        self.fc = nn.Linear(hidden_dim, num_class)   #nn.Linear是全连接层，rnn输出一个32维的向量，用这个32维的向量再作为一个输入，放进nn.Linear输出5维的向量,哪个位置数字最大就在哪一位

    
    def forward(self, x):
        # x: [batch, seq_len=5]
        x = self.embedding(x)  # [batch, 5, 16]
        out, h_n = self.rnn(x)  #out就是self.rnn的每一个字读完后，每一步的32维记忆(一共5个，对应5个字)，h_n是最后第5个字读完后的那1个最终32维的
        # 取最后一个时间步输出
        out = self.fc(h_n.squeeze(0))
        return out   #这里return出的是nn.Linear算出的5维向量

# 2. LSTM模型
class LSTMClassifier(nn.Module):    #用把不重要的东西主动擦掉，相当于遗忘或是擦掉，有一个长期记忆重要内容，有一个短期记忆新内容，不重要的会被擦掉
    def __init__(self, vocab_size, embed_dim, hidden_dim, num_class):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim)
        self.lstm = nn.LSTM(embed_dim, hidden_dim, batch_first=True)
        self.fc = nn.Linear(hidden_dim, num_class)
    
    def forward(self, x):   #forward是前向传播，固定写法
        x = self.embedding(x)
        out, (h_n, _) = self.lstm(x)  #把上面self.embedding算出来的带进self.lstm去算出h_n, _；rnn只有短期记忆所以只有h_n,lstm有长期记忆所以还有_,都是带进上面去算出来的。
        out = self.fc(h_n.squeeze(0)) #squeeze(0)是要把第0维的1删掉
        return out

# ===================== 5. 训练与测试函数 =====================
def train_and_eval(model, epochs=10):     #model是我上面写的模型，传上面的rnn模型就训练rnn，传lstm就训练lstm
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")  #这里主要是有显卡用显卡，没显卡用cpu自动适配，cude是显卡
    model = model.to(device)   #这里指的是我的device是显卡，模型就显卡跑，device是cpu跑模型就cpu跑。
    criterion = nn.CrossEntropyLoss()  #交叉熵损失函数拿过来。
    optimizer = optim.Adam(model.parameters(), lr=1e-3)  #模型优化器，model.parameters()就是模型要优化的数据，数据从criterion拿到，把这个数据给到adam，按照lr的步子来调优。
                                                       #parameters=改谁
    for epoch in range(epochs):  #epochs没指定数字默认是10，若有指定数字就默认指定的。
        # 训练
        model.train()  #让模型进入训练模式
        total_loss = 0
        for batch_x, batch_y in train_loader:   #batch_x是这一批的输入数据，batch_y是真实值
            batch_x, batch_y = batch_x.to(device), batch_y.to(device)  #这里需要手动改一下模型用device来跑，所以用batch_x.to(device), batch_y.to(device)
            optimizer.zero_grad()  #跑之前先梯度清零；先清零 → 再预测 → 算损失 → 反向传 → 改参数
            pred = model(batch_x)   #用这个输入数据带到我要训练的模型里面算出pred
            loss = criterion(pred, batch_y)
            loss.backward()    #反向传播，用这个loss算出每个参数要怎么改梯度，下次要变大一点还是变小一点。
            optimizer.step()   #按梯度去改参数，按照backward算出的梯度，实际更新模型里所有的权重参数，让模型下次预测的更准确
            total_loss += loss.item()   #把每一批的loss加起来。每批是10条
        
        # 测试
        model.eval()  #模型进入训练评估模式
        correct = 0
        with torch.no_grad():  #训练时不需要算梯度，更新参数，不用反向传播算的更快。
            for batch_x, batch_y in test_loader:
                batch_x, batch_y = batch_x.to(device), batch_y.to(device)
                pred = model(batch_x)
                pred_label = torch.argmax(pred, dim=1)  #dim=1按行看，找该行对应最大数的下标，pred的最大数的下标，最大数是第几个下标就是几
                correct += (pred_label == batch_y).sum().item()  #sum是把我前面的猜对的数据加起来，.item是把加起来的数字转化成普通数字可以和前面的correct加
        acc = correct / len(test_dataset)  #len(test_dataset测试集的总样本长度。
        print(f"Epoch [{epoch+1}/{epochs}] Loss:{total_loss:.4f} Acc:{acc:.4f}")

# ===================== 6. 运行实验 =====================
if __name__ == "__main__":
    print("===== 训练 RNN 模型 =====")
    rnn_model = RNNClassifier(vocab_size, embed_dim, hidden_dim, num_class)
    train_and_eval(rnn_model, epochs=10)

    print("\n===== 训练 LSTM 模型 =====")
    lstm_model = LSTMClassifier(vocab_size, embed_dim, hidden_dim, num_class)
    train_and_eval(lstm_model, epochs=10)